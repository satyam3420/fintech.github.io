const Eimages ={
    walllet:require('./Ellipse 10.png').default
}

export default Eimages