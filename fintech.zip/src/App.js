import React from 'react'
import HomePage from './Pages/HomePage'

const App = () => {
  return (
    <HomePage />
  )
}

export default App